def build_fragment_from_xyz(xyz_path, cfg=None):
    return {'qubit_hamiltonian': None}
