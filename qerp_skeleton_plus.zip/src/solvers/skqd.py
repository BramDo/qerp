def skqd_time_krylov(estimator, H, psi0, K=6, dt=0.2):
    return {'eigenvalues':[0.0], 'S_condition':1.0}
