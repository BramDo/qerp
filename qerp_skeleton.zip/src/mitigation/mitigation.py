from __future__ import annotations
def apply_readout_correction(data): return data  # stub
def symmetry_filter(bitstrings): return bitstrings  # stub
def zne_fold(circuit, level=1): return circuit  # stub
